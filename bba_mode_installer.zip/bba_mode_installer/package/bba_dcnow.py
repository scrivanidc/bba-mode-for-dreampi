#!/usr/bin/env python

import threading
import os
import json
import time
import logging
import urllib
import urllib2
import sh
import re
from hashlib import sha256

from uuid import getnode as get_mac

logger = logging.getLogger('dcnow')
API_ROOT = "https://dcnow-2016.appspot.com"
UPDATE_END_POINT = "/api/update/{mac_address}/"
UPDATE_INTERVAL = 15
CONFIGURATION_FILE = os.path.expanduser("/home/pi/dreampi/bba_mode/.bba_dcnow.json")
gameloft = False

def scan_mac_address():
    mac = get_mac()

    try:
        with open("/home/pi/dreampi/bba_mode/bba_mac.txt", "r") as file:
           bba_mac = None
           bba_mac = file.readline().strip().replace("-", ":")
        if bba_mac and not bba_mac.startswith("#") and re.match(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$', bba_mac):
            mac = int(bba_mac.replace(":", ""), 16)
            logger.info("Custom Mac Address file found, using for DCNow profile")
    except Exception as e:
        logger.info("Custom Mac Address file not found, using default from network interface")

    return sha256(':'.join(("%012X" % mac)[i:i+2] for i in range(0, 12, 2))).hexdigest()

class DreamcastNowThread(threading.Thread):
    def __init__(self, service):
        self._service = service
        self._running = True
        super(DreamcastNowThread, self).__init__()

    def run(self):
        def post_update():
            if not self._service._enabled:
                return
            global gameloft
            lines = [ x for x in sh.tail("/var/log/syslog", "-n", "300", _iter=True) ]
            dns_query = None
            for line in lines[::-1]:
                if "query[A]" in line:
                    # We did a DNS lookup, what was it?
                    remainder = line[line.find("query[A]") + len("query[A]"):].strip()
                    domain = remainder.split(" ", 1)[0].strip()
                    dns_query = sha256(domain).hexdigest()
                    
                    #Send monaco/pod/speed just once - Begin
                    if gameloft and "gameloft" in domain: ## already sent, do not send again.
                        dns_query = None
                        break
                    if "gameloft" in domain: ## first read, send.
                        gameloft = True
                        logger.info("Domain sent to DCNow API: " + domain)
                        break
                    #Send monaco/pod/speed just once - End

                    if "appspot" in domain:
                        pass
                    else:
                        logger.info("Domain sent to DCNow API: " + domain)
                        break
            
            user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT), Dreamcast Now'
            header = { 'User-Agent' : user_agent }
            mac_address = self._service._mac_address
            data = {}
            if dns_query:
                data["dns_query"] = dns_query

            data = urllib.urlencode(data)
            req = urllib2.Request(API_ROOT + UPDATE_END_POINT.format(mac_address=mac_address), data, header)
            urllib2.urlopen(req) # Send POST update

        while self._running:
            try:
                post_update()
            except:
                logger.info("Couldn't update Dreamcast Now!")
            dcnow_run.wait(UPDATE_INTERVAL)

    def stop(self):
        self._running = False
        self.join()


class DreamcastNowService(object):
    def __init__(self):
        self._thread = None
        self._mac_address = None
        self._enabled = True
        self.reload_settings()

        logger.setLevel(logging.INFO)
        handler = logging.handlers.SysLogHandler(address='/dev/log')
        logger.addHandler(handler)
        formatter = logging.Formatter('%(name)s[%(process)d]: %(message)s')
        handler.setFormatter(formatter)    

    def update_mac_address(self):
        self._mac_address = scan_mac_address()
        logger.info("MAC address: {}".format(self._mac_address))

    def reload_settings(self):
        settings_file = CONFIGURATION_FILE

        if os.path.exists(settings_file):
            with open(settings_file, "r") as settings:
                content = json.loads(settings.read())
                self._enabled = content["enabled"]

    def go_online(self):
        logger.propagate = False
        if not self._enabled:
            return
        global dcnow_run
        dcnow_run = threading.Event()
        self.update_mac_address()
        self._thread = DreamcastNowThread(self)
        self._thread.start()
        logger.info("DC Now Session Started")

    def go_offline(self):
        global dcnow_run, gameloft
        try:
            gameloft = False
            dcnow_run.set()
            if self._thread:
                self._thread.stop()
                self._thread = None
        except Exception:
            pass
        logger.info("DC Now Session Ended")
        self.cleanup()
        
    def cleanup(self):
        try:
            if hasattr(self, "_thread") and self._thread:
                self._thread.stop()
                self._thread = None
        except Exception:
            pass

        for handler in logger.handlers[:]:
            logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass
